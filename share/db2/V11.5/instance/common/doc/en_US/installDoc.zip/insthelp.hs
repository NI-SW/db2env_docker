<?xml version="1.0" encoding="ISO-8859-1" ?>
<!DOCTYPE helpset
  PUBLIC "-//Sun Microsystems Inc.//DTD JavaHelp HelpSet Version 1.0//EN"
         "http://java.sun.com/products/javahelp/helpset_1_0.dtd">

<helpset version="1.0">
  <!-- title -->
  <title>DB2 Installation Help</title>

  <!-- views -->
  <view>
    <name>TOC</name>
    <label>Contents</label>
    <type>javax.help.TOCView</type>
  </view>

  <!-- subhelpsets -->

  <subhelpset location="maxLogicalPart.hs"/>
  <subhelpset location="installSelector.hs"/>
  <subhelpset location="intro.hs"/>
  <subhelpset location="iSetupIntro.hs"/>
  <subhelpset location="license.hs"/>
  <subhelpset location="installType.hs"/>
  <subhelpset location="iSetupInstallAction.hs"/>
  <subhelpset location="installAction.hs"/>
  <subhelpset location="installLocation.hs"/>
  <subhelpset location="selDb2Feat.hs"/>
  <subhelpset location="selectLangs.hs"/>
  <subhelpset location="configDocLocation.hs"/>
  <subhelpset location="dasUser.hs"/>
  <subhelpset location="createInst.hs"/>
  <subhelpset location="instanceUse.hs"/>
  <subhelpset location="instUser.hs"/>
  <subhelpset location="chooseUser.hs"/>
  <subhelpset location="fencUser.hs"/>
  <subhelpset location="clusterFileSysDB2Managed.hs"/>
  <subhelpset location="clusterFileSysAllOptions.hs"/>
  <subhelpset location="hostSelection.hs"/>
  <subhelpset location="sdAdvancedAllSettings.hs"/>
  <subhelpset location="sdAdvancedCAOnly.hs"/>
  <subhelpset location="addHost.hs"/>
  <subhelpset location="commProt.hs"/>
  <subhelpset location="contactSetup.hs"/>
  <subhelpset location="addContact.hs"/>
  <subhelpset location="remoteLogon.hs"/>
  <subhelpset location="configTextSearch.hs"/>
  <subhelpset location="summary.hs"/>
  <subhelpset location="cdPrompt.hs"/>
  <subhelpset location="selectDocLangs.hs"/>
  <subhelpset location="configDocServer.hs"/>
  <subhelpset location="setupRcon.hs"/>
  <subhelpset location="oracle.hs"/>
  <subhelpset location="sybase.hs"/>
  <subhelpset location="informix.hs"/>
  <subhelpset location="sqlServer.hs"/>
  <subhelpset location="teradata.hs"/>

</helpset>